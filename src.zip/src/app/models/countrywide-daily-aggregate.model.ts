export class CountrywideDailyAggregate {
  date: any;
  country: any;
  confirmed: any;
  recovered: any;
  deaths: any;
}

export class WorldwideDailyAggregate {
  date: any;
  confirmed: any;
  recovered: any;
  deaths: any;
  increaseRate: any;
}

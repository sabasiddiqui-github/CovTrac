import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { CountrywideDailyAggregate } from 'src/app/models/countrywide-daily-aggregate.model';
import { CountrywideDataService } from 'src/app/services/countrywide-data.service';
import { DatewiseTableComponent } from './datewise-table/datewise-table.component';
import { SelectBarComponent } from './select-bar/select-bar.component';

@Component({
  selector: 'app-countries-page',
  templateUrl: './countries-page.component.html',
  styleUrls: ['./countries-page.component.css']
  
})
export class CountriesPageComponent implements OnInit {
  countryData:CountrywideDailyAggregate[] = [];
  countries:string[]=[];
  //DateWiseData:CountrywideDailyAggregate[]=[];
  
  //selectedDataTable:sele[]=[]; 
  selectedCountryData:CountrywideDailyAggregate[];
  @Input()
  data:any;
  var : any;
  //@ViewChild('SelectBarComponent') Selectbar: SelectBarComponent; 
  constructor(private countrywideDataService:CountrywideDataService) { }

  ngOnInit(): void {
    this.getAllCountrywideData();
    this.countrywideDataService.getCountryData().subscribe((result: any) => {
      this.countryData=result;
      console.log(this.countryData);
    })
    
    
    
  }
  //parentFunction(data: any){
  //  console.log(data)
  //}
  parentComponent(data:any){
    this.var = data;
    console.log(data);
  }

  
 
  getAllCountrywideData(){
    this.countrywideDataService.getCountryData().subscribe((data: any) => {
      this.countryData = data[0];
      this.countries = data[1];
      console.log(this.countries);

      //console.log(this.countryData);
    });
  
  }
  updateValue(country:any){
    console.log(country);
    this.selectedCountryData=this.countryData[country];
    
    //return this.selectedCountryData;
    //this.sendData.emit(country);
  

  }
 
  

}

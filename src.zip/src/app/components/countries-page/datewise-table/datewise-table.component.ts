import { Component, Input, OnInit } from '@angular/core';
import { SelectBarComponent } from '../select-bar/select-bar.component';

@Component({
  selector: 'app-datewise-table',
  templateUrl: './datewise-table.component.html',
  styleUrls: ['./datewise-table.component.css']
})
export class DatewiseTableComponent implements OnInit{
  @Input()
  data : any;

  @Input()
  scope : any;
  selected:string[]=[];


  constructor() { 

  }

  ngOnInit(): void {
   var select=new SelectBarComponent();
   this.selected.push(select.selectedCountryData);
}



}
